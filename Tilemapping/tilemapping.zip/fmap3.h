#include <sdl/sdl.h>

#pragma comment (lib,"sdl.lib")      // ignorez ces lignes si vous ne linkez pas les libs de cette fa�on.
#pragma comment (lib,"sdlmain.lib")

typedef struct
{
	SDL_Rect R;
	char mur;
	// tout ce que vous voulez...

} TileProp;

typedef struct
{
	int LARGEUR_TILE,HAUTEUR_TILE;
	int nbtiles;
	TileProp* props;
	SDL_Surface* tileset;
	unsigned char** schema;
	int nbtiles_largeur_monde,nbtiles_hauteur_monde;
} Map;

Map* ChargerMap(const char* tileset,const char* image_schema,const char* image_corr,const char* tileprop,int largeur_tile,int hauteur_tile);
int AfficherMap(Map* m,SDL_Surface* screen);
int LibererMap(Map* m);
