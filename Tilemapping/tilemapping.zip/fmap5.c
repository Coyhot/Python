#define _CRT_SECURE_NO_DEPRECATE   // pour visual C++ qui met des warning pour fopen et fscanf : aucun effet negatif pour les autres compilos.
#include <string.h>
#include "fmap5.h"

SDL_Surface* LoadImage32(const char* fichier_image,int vram)
{
	SDL_Surface* image_result;
	SDL_Surface* image_ram = SDL_LoadBMP(fichier_image);	// charge l'image dans image_ram en RAM
	if (image_ram==NULL)
	{
		printf("Image %s introuvable !! \n",fichier_image);
		SDL_Quit();
		exit(-1);
	}
	image_result = NULL;
	if (vram)
		image_result=SDL_CreateRGBSurface(SDL_HWSURFACE, image_ram->w, image_ram->h, 32, 0, 0, 0, 0);  // cree une imageen VRAM
	if (image_result==NULL)
		vram = 0;
	if (!vram)
		image_result=SDL_CreateRGBSurface(SDL_SWSURFACE, image_ram->w, image_ram->h, 32, 0, 0, 0, 0);  // cree une image en RAM
	SDL_BlitSurface(image_ram,NULL,image_result,NULL);	// copie l'image image_ram de moins de 32 bits vers image_result qui fait 32 bits
	SDL_FreeSurface(image_ram);      // supprime la surface image_ram : inutile maintenant --> libere la m�moire
	return image_result;
}

Uint32 GetPixel32(SDL_Surface* image,int i,int j)
{
	if (i<0 || i>image->w-1 || j<0 || j>image->h-1)
		return 0;
	return ((Uint32*)(image->pixels))[j*(image->pitch/4)+i];   // lecture directe des pixels
}

char LocatePixInCorr(SDL_Surface* corr,Uint32 pix)
{
	int i,j;
	for(j=0;j<corr->h;j++)
		for(i=0;i<corr->w;i++)
			if (GetPixel32(corr,i,j)==pix)
				return (char)(j*corr->w + i);
	return 0;
}

TileProp* ChargerProps(const char* tileprop,int nombre_props)
{
	char buf[500];
	FILE* F;
	int i,j;
	int index;
	TileProp* res = calloc(nombre_props,sizeof(TileProp)); // alloue et met tout a 0.
	F = fopen(tileprop,"r");
	if (F==NULL)
	{
		printf("fichier %s introuvable !!\n",tileprop);
		exit(-1);
	}
	for(i=0;i<nombre_props;i++)
	{
		fscanf(F,"%d",&index);
		if (index==-1)
			break;
		fscanf(F,"%s",buf);
		if (strcmp(buf,"mur")==0)
			res[i].mur = 1;
		fscanf(F,"%s",buf);
		if (strcmp(buf,"invisible")==0)
			res[i].invisible = 1;
		fscanf(F,"%d",&res[i].nbframes);
		if (res[i].nbframes!=0)
		{
			fscanf(F,"%d",&res[i].speedanim);
			res[i].listanim = malloc(res[i].nbframes*sizeof(int));
			for(j=0;j<res[i].nbframes;j++)
				fscanf(F,"%d",&res[i].listanim[j]);
		}
	}
	fclose(F);
	return res;
}

void CalculerSDLRects(TileProp* tabprops,int nombre_props,int nombre_tiles_largeur,int largeur_tile,int hauteur_tile)
{
	int i;
	for(i=0;i<nombre_props;i++)
	{
		tabprops[i].R.w = largeur_tile;
		tabprops[i].R.h = hauteur_tile;
		tabprops[i].R.x = largeur_tile*(i%nombre_tiles_largeur);
		tabprops[i].R.y = hauteur_tile*(i/nombre_tiles_largeur);
	}
}


Map* ChargerMap(const char* tileset,const char* image_schema,const char* image_corr,const char* tileprop,int largeur_tile,
				int hauteur_tile,int largeur_fenetre,int hauteur_fenetre,unsigned char Rmask,unsigned char Gmask,unsigned char Bmask)
{
	int i,j;
	Map* res;
	SDL_Surface* schema,*corr;
	Uint32 pix;
	res = malloc(sizeof(Map));
	res->LARGEUR_TILE = largeur_tile;
	res->HAUTEUR_TILE = hauteur_tile;
	res->tileset = LoadImage32(tileset,1);  // charge le tileset en VRAM pour meilleur vitesse de Blit.
	schema = LoadImage32(image_schema,0);
	corr = LoadImage32(image_corr,0);
	res->nbtiles = (res->tileset->w / largeur_tile) * (res->tileset->h / hauteur_tile);
	res->props = ChargerProps(tileprop,res->nbtiles);
	CalculerSDLRects(res->props,res->nbtiles,res->tileset->w / largeur_tile,largeur_tile,hauteur_tile);
	res->nbtiles_largeur_monde = schema->w;
	res->nbtiles_hauteur_monde = schema->h;
	res->schema = malloc(schema->w * sizeof(char*));
	for(i=0;i<schema->w;i++)
	{
		res->schema[i] = malloc(schema->h * sizeof(char));
		for(j=0;j<schema->h;j++)
		{
			pix = GetPixel32(schema,i,j);
			res->schema[i][j] = LocatePixInCorr(corr,pix);
		}
	}
	SDL_FreeSurface(schema);
	SDL_FreeSurface(corr);
	res->largeur_fenetre = largeur_fenetre;
	res->hauteur_fenetre = hauteur_fenetre;
	res->xscroll = 0;
	res->yscroll = 0;
	SDL_SetColorKey(res->tileset,SDL_SRCCOLORKEY ,SDL_MapRGBA(res->tileset->format,Rmask,Gmask,Bmask,0));
	return res;
}

int AfficherMap(Map* m,SDL_Surface* screen)
{
	int i,j;
	SDL_Rect Rect_dest;
	int numero_tile;
	int minx,maxx,miny,maxy;
	minx = m->xscroll / m->LARGEUR_TILE;
	miny = m->yscroll / m->HAUTEUR_TILE;
	maxx = (m->xscroll + m->largeur_fenetre)/m->LARGEUR_TILE;
	maxy = (m->yscroll + m->hauteur_fenetre)/m->HAUTEUR_TILE;
	for(i=minx;i<=maxx;i++)
	{
		for(j=miny;j<=maxy;j++)
		{
			Rect_dest.x = i*m->LARGEUR_TILE - m->xscroll;
			Rect_dest.y = j*m->HAUTEUR_TILE - m->yscroll;
			numero_tile = m->schema[i][j];
			if (m->props[numero_tile].nbframes!=0) // animation tiles
				numero_tile = m->props[numero_tile].listanim[(SDL_GetTicks()/m->props[numero_tile].speedanim)%m->props[numero_tile].nbframes];
			if (!m->props[numero_tile].invisible)
				SDL_BlitSurface(m->tileset,&(m->props[numero_tile].R),screen,&Rect_dest);
		}
	}
	return 0;
}

int LibererMap(Map* m)
{
	int i;
	for(i=0;i<m->nbtiles_largeur_monde;i++)
		free(m->schema[i]);
	for(i=0;i<m->nbtiles;i++)
		if (m->props[i].listanim!=NULL)
			free(m->props[i].listanim);
	free(m->schema);
	free(m->props);
	free(m);
	return 0;
}
