#include <SDL/SDL.h>

#pragma comment (lib,"sdl.lib")      // ignorez ces lignes si vous ne linkez pas les libs de cette fa�on.
#pragma comment (lib,"sdlmain.lib")

#define LARGEUR_TILE 24  // hauteur et largeur des tiles.
#define HAUTEUR_TILE 16 

// -----------------------------------------------------------

SDL_Surface* LoadImage32(const char* fichier_image,int vram)
{
	SDL_Surface* image_result;
	SDL_Surface* image_ram = SDL_LoadBMP(fichier_image);	// charge l'image dans image_ram en RAM
	if (image_ram==NULL)
	{
		printf("Image %s introuvable !! \n",fichier_image);
		SDL_Quit();
		exit(-1);
	}
	image_result = NULL;
	if (vram)
		image_result=SDL_CreateRGBSurface(SDL_HWSURFACE, image_ram->w, image_ram->h, 32, 0, 0, 0, 0);  // cree une imageen VRAM
	if (image_result==NULL)
		vram = 0;
	if (!vram)
		image_result=SDL_CreateRGBSurface(SDL_SWSURFACE, image_ram->w, image_ram->h, 32, 0, 0, 0, 0);  // cree une image en RAM
	SDL_BlitSurface(image_ram,NULL,image_result,NULL);	// copie l'image image_ram de moins de 32 bits vers image_result qui fait 32 bits
	SDL_FreeSurface(image_ram);      // supprime la surface image_ram : inutile maintenant --> libere la m�moire
	return image_result;
}

Uint32 GetPixel32(SDL_Surface* image,int i,int j)
{
	if (i<0 || i>image->w-1 || j<0 || j>image->h-1)
		return 0;
	return ((Uint32*)(image->pixels))[j*(image->pitch/4)+i];   // lecture directe des pixels
}

char LocatePixInCorr(SDL_Surface* corr,Uint32 pix)
{
	int i;
	for(i=0;i<corr->w;i++)
		if (GetPixel32(corr,i,0)==pix)
			return (char)i;
	return 0;
}

char** ChargerMap(const char* image_schema,const char* image_corr,int* nombre_blocs_largeur,int* nombre_blocs_hauteur)
{
	Uint32 pix;
	char** res;
	SDL_Surface* schema,*corr;
	int i,j;
	schema = LoadImage32(image_schema,0);
	corr = LoadImage32(image_corr,0);
	res = malloc(schema->w * sizeof(char*));
	for(i=0;i<schema->w;i++)
	{
		res[i] = malloc(schema->h * sizeof(char));
		for(j=0;j<schema->h;j++)
		{
			pix = GetPixel32(schema,i,j);
			res[i][j] = LocatePixInCorr(corr,pix);
		}
	}
	*nombre_blocs_largeur = schema->w;
	*nombre_blocs_hauteur = schema->h;
	SDL_FreeSurface(schema);
	SDL_FreeSurface(corr);
	return res;
}

void LibererMap(char** table,int nombre_blocs_largeur)
{
	int i;
	for(i=0;i<nombre_blocs_largeur;i++)
		free(table[i]);
	free(table);
}


// -----------------------------------------------------------

void Afficher(SDL_Surface* screen,SDL_Surface* tileset,char** table,int nombre_blocs_largeur,int nombre_blocs_hauteur)
{
	int i,j;
	SDL_Rect Rect_dest;
	SDL_Rect Rect_source;
	Rect_source.w = LARGEUR_TILE;
	Rect_source.h = HAUTEUR_TILE;
	for(i=0;i<nombre_blocs_largeur;i++)
	{
		for(j=0;j<nombre_blocs_hauteur;j++)
		{
			Rect_dest.x = i*LARGEUR_TILE;
			Rect_dest.y = j*HAUTEUR_TILE;
			Rect_source.x = (table[i][j])*LARGEUR_TILE;
			Rect_source.y = 0;
			SDL_BlitSurface(tileset,&Rect_source,screen,&Rect_dest);
		}
	}
	SDL_Flip(screen);
}

int main(int argc,char** argv)
{
	SDL_Surface* screen,*tileset;
	char** table;
	int nombre_blocs_largeur,nombre_blocs_hauteur;
	SDL_Event event;
	SDL_Init(SDL_INIT_VIDEO);		// preapare SDL

	table = ChargerMap("level1.bmp","corresp1.bmp",&nombre_blocs_largeur,&nombre_blocs_hauteur);

	screen = SDL_SetVideoMode(LARGEUR_TILE*nombre_blocs_largeur, HAUTEUR_TILE*nombre_blocs_hauteur, 32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	tileset = LoadImage32("tileset1.bmp",1);

	Afficher(screen,tileset,table,nombre_blocs_largeur,nombre_blocs_hauteur);
	LibererMap(table,nombre_blocs_largeur);

	do 
	{
		SDL_WaitEvent(&event);
	} while (event.type!=SDL_KEYDOWN);

	SDL_FreeSurface(tileset);
	SDL_Quit();
	return 0;
}