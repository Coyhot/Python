#include "fmap3.h"

int main(int argc,char** argv)
{
	SDL_Surface* screen;
	SDL_Event event;
	Map* carte;
	SDL_Init(SDL_INIT_VIDEO);		// preapare SDL
	carte = ChargerMap("tileset1.bmp","level2.bmp","corresp1.bmp","tileprop1.txt",24,16);
	screen = SDL_SetVideoMode(carte->LARGEUR_TILE*carte->nbtiles_largeur_monde,carte->HAUTEUR_TILE*carte->nbtiles_hauteur_monde,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	AfficherMap(carte,screen);
	SDL_Flip(screen);
	do 
	{
		SDL_WaitEvent(&event);
	} while (event.type!=SDL_MOUSEBUTTONDOWN);
	LibererMap(carte);
	SDL_Quit();
	return 0;
}
