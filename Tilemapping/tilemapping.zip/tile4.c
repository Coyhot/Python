#include "fmap4.h"

typedef struct
{
	char key[SDLK_LAST];
} Input;

void UpdateEvents(Input* in)
{
	SDL_Event event;
	while(SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			in->key[event.key.keysym.sym]=1;
			break;
		case SDL_KEYUP:
			in->key[event.key.keysym.sym]=0;
			break;
		default:
			break;
		}
	}
}

void MoveMap(Map* m,Input* in)
{
	if (in->key[SDLK_LEFT])
		m->xscroll-=5;
	if (in->key[SDLK_RIGHT])
		m->xscroll+=5;
	if (in->key[SDLK_UP])
		m->yscroll-=5;
	if (in->key[SDLK_DOWN])
		m->yscroll+=5;
// limitation
	if (m->xscroll<0)
		m->xscroll=0;
	if (m->yscroll<0)
		m->yscroll=0;
	if (m->xscroll>m->nbtiles_largeur_monde*m->LARGEUR_TILE-m->largeur_fenetre-1)
		m->xscroll=m->nbtiles_largeur_monde*m->LARGEUR_TILE-m->largeur_fenetre-1;
	if (m->yscroll>m->nbtiles_hauteur_monde*m->HAUTEUR_TILE-m->hauteur_fenetre-1)
		m->yscroll=m->nbtiles_hauteur_monde*m->HAUTEUR_TILE-m->hauteur_fenetre-1;
}



int main(int argc,char** argv)
{
	SDL_Surface* screen;
	Map* carte;
	Input in;
	memset(&in,0,sizeof(in));
	SDL_Init(SDL_INIT_VIDEO);		// preapare SDL
	carte = ChargerMap("tileset1.bmp","level2.bmp","corresp1.bmp","tileprop1.txt",24,16,400,300);
	screen = SDL_SetVideoMode(carte->largeur_fenetre,carte->hauteur_fenetre,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	while(!in.key[SDLK_ESCAPE])
	{
		unsigned int elapsed;
		unsigned int lasttime = SDL_GetTicks();
		UpdateEvents(&in);
		MoveMap(carte,&in);
		AfficherMap(carte,screen);
		SDL_Flip(screen);
		elapsed = SDL_GetTicks()-lasttime;
		if (elapsed<20)					
			SDL_Delay(20-elapsed);		
	}
	LibererMap(carte);
	SDL_Quit();
	return 0;
}
