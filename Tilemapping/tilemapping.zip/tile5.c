#include "fmap5.h"

typedef struct
{
	char key[SDLK_LAST];
} Input;

void UpdateEvents(Input* in)
{
	SDL_Event event;
	while(SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			in->key[event.key.keysym.sym]=1;
			break;
		case SDL_KEYUP:
			in->key[event.key.keysym.sym]=0;
			break;
		default:
			break;
		}
	}
}

void MoveMap(Map* front,Map* back,Input* in)
{
	int speed = 6;
	if (in->key[SDLK_LEFT])
		front->xscroll-=speed;
	if (in->key[SDLK_RIGHT])
		front->xscroll+=speed;
	if (in->key[SDLK_UP])
		front->yscroll-=speed;
	if (in->key[SDLK_DOWN])
		front->yscroll+=speed;
	// limitation
	if (front->xscroll<0)
		front->xscroll=0;
	if (front->yscroll<0)
		front->yscroll=0;
	if (front->xscroll>front->nbtiles_largeur_monde*front->LARGEUR_TILE-front->largeur_fenetre-1)
		front->xscroll=front->nbtiles_largeur_monde*front->LARGEUR_TILE-front->largeur_fenetre-1;
	if (front->yscroll>front->nbtiles_hauteur_monde*front->HAUTEUR_TILE-front->hauteur_fenetre-1)
		front->yscroll=front->nbtiles_hauteur_monde*front->HAUTEUR_TILE-front->hauteur_fenetre-1;
	// fond
	back->xscroll = front->xscroll/2;
	back->yscroll = front->yscroll/2;
}




int main(int argc,char** argv)
{
	SDL_Surface* screen;
	Map* front,*back;
	Input in;
	memset(&in,0,sizeof(in));
	SDL_Init(SDL_INIT_VIDEO);		// preapare SDL
	front = ChargerMap("tileset2.bmp","level3.bmp","corresp2.bmp","tileprop2.txt",24,16,400,300,95,117,202);
	back = ChargerMap("tilesetback.bmp","backgrnd.bmp","backgrnd.bmp","tilepropback.txt",256,216,400,300,255,0,255);
	screen = SDL_SetVideoMode(front->largeur_fenetre,front->hauteur_fenetre,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	while(!in.key[SDLK_ESCAPE])
	{
		unsigned int elapsed;
		unsigned int lasttime = SDL_GetTicks();
		UpdateEvents(&in);
		MoveMap(front,back,&in);
		AfficherMap(back,screen);
		AfficherMap(front,screen);
		SDL_Flip(screen);
		elapsed = SDL_GetTicks()-lasttime;
		if (elapsed<20)					
			SDL_Delay(20-elapsed);		
	}
	LibererMap(front);
	LibererMap(back);
	SDL_Quit();
	return 0;
}
